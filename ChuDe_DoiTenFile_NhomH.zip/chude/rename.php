<?php

session_start();

if (isset($_POST['submit'])) {
    $dir = $_POST['linkFile'];

    function getDirContents($dir, &$results = array()) {
        $files = scandir($dir);

        foreach ($files as $key => $value) {
            $path = realpath($dir . DIRECTORY_SEPARATOR . $value);
            if (!is_dir($path)) {
                $results[] = $path;
            } else if ($value != "." && $value != "..") {
                getDirContents($path, $results);
                $results[] = $path;
            }
        }
        return $results;
    }
    
//    var_dump(getDirContents($dir));    die();

    if (!empty($_POST['old_filename']) && !empty($_POST['new_filename'])) {
        $old_name = $_POST['old_filename'];
        $new_name = $_POST['new_filename'];

//        $handle = opendir(getDirContents($dir));

        if (file_exists($new_name)) {
                $mes = "Error While Renaming $old_name";
                echo "<script type='text/javascript'>alert('$mes');</script>";
            } else {
                if (rename($old_name, $new_name)) {
                    $mes = "Successfully Renamed $old_name to $new_name";
                    echo "<script type='text/javascript'>alert('$mes');</script>";
                } else {
                    $mes = "A File With The Same Name Already Exists";
                    echo "<script type='text/javascript'>alert('$mes');</script>";
                }
            }
        
    }
}

//
////        $scdir = scandir($dir);
//
//        function getDirContents($dir, $filter = '', &$results = array()) {
//            $files = scandir($dir);
//
//            foreach ($files as $key => $value) {
//                $path = realpath($dir . DIRECTORY_SEPARATOR . $value);
//
//                if (!is_dir($path)) {
//                    if (empty($filter) || preg_match($filter, $path))
//                        $results[] = $path;
//                } else if ($value != "." && $value != "..") {
//                    getDirContents($path, $filter, $results);
//                }
//            }
//
//            if (file_exists($new_name)) {
//                $mes = "Error While Renaming $old_name";
//                echo "<script type='text/javascript'>alert('$mes');</script>";
//            } else {
//                if (rename($old_name, $new_name)) {
//                    $mes = "Successfully Renamed $old_name to $new_name";
//                    echo "<script type='text/javascript'>alert('$mes');</script>";
//                } else {
//                    $mes = "A File With The Same Name Already Exists";
//                    echo "<script type='text/javascript'>alert('$mes');</script>";
//                }
//            }
//
//            return $results;
//        }
//
//        $a = getDirContents($dir);

    //        if (!empty($_POST['old_filename']) && !empty($_POST['new_filename'])) {
//            
//        } else {
//            $mes = "Vui long nhap day du";
//            echo "<script type='text/javascript'>alert('$mes');</script>";
//        }
//        var_dump(getDirContents($dir));
//        die();
//    } else {
//        $mes = "Vui long nhap vao link";
//        echo "<script type='text/javascript'>alert('$mes');</script>";
//    }

//
//
//    while ($file = readdir($handle)) {
//        if ($file != '.' && $file != '..') {
//            $dir = $dir . "<option>$file</option>";
//        }
//    }