<?php
include('rename.php');
?>


<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>1054</title>
        <link href="../chude/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../chude/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../chude/css/1054.css" rel="stylesheet" type="text/css"/>

        <script type="text/javascript">

        </script>

    </head>

    <body>
        <div class="type-1054">
            <div class="container">
                <div class="row">
                    <!--BACKGROUND-->
                    <div class="cover-bg"></div>
                    <!--/END BACKGROUND-->

                    <div class="landing-page">
                        <div class="login-page account-container">
                            <h1>RENAME FILE</h1>
                            <main>
                                <form action="#" method="post">
                                    <?php if (isset($_POST['linkFile'])): ?>
                                        <input type="text" name="old_filename" placeholder="input old file name" class="simple-input">
                                        <hr>
                                        <input type="text" name="new_filename" placeholder="input new file name" class="simple-input">
                                        <button type="submit" id="submit" name="submit" class="submit-button black">Submit</button>
                                        <select><option><?php echo implode("||", getDirContents($dir)) ?></option></select>
                                    <?php endif; ?>
                                    <?php if (!isset($_POST['linkFile'])): ?>
                                        <input type="text" name="linkFile" placeholder="input link" value="" class="simple-input">
                                        <button type="submit" id="submit" name="submit" class="submit-button black">Load</button>
                                    <?php endif; ?>

                                </form>
                            </main>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>

</html>
